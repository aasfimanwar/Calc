# Calculator
Android Workshop: Assignment 1 Calculator with single mode button to toggle between operations
